package com.csscorp.collections.generic;

public class Main {

	public static void main(String[] args) {
		Array<Integer> integ=new Array<Integer>();
		integ.setT(new Integer(123));
		System.out.println(integ.getT());
		
		
	}
	

}
